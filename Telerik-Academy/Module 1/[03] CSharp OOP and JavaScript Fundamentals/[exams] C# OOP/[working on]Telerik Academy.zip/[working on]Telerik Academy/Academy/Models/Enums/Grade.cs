﻿namespace Academy.Models.Enums
{
    public enum Grade
    {
        Failed = 0,
        Passed = 1,
        Excellent = 2
    }
}
