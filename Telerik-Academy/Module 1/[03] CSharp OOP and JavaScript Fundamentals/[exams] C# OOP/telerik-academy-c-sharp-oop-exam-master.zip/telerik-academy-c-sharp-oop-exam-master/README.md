# Telerik Academy - C# OOP - Exam - January 2017
